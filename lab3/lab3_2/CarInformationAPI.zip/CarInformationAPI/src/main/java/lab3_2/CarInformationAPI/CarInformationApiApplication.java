package lab3_2.CarInformationAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarInformationApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarInformationApiApplication.class, args);
	}

}
