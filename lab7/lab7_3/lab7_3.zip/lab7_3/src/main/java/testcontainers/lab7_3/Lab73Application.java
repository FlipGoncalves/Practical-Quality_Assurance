package testcontainers.lab7_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab73Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab73Application.class, args);
	}

}
